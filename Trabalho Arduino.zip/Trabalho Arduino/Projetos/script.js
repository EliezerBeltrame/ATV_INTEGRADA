const urlBase = "http://localhost:1880";

async function buscarDados() {
    try {
        const response = await fetch(`${urlBase}/atual`);
        let texto = await response.text();

        texto = texto.replace(/'/g, '"');
        const data = JSON.parse(texto);

        document.getElementById("temp").innerText = data.temperatura + "°C";
        document.getElementById("umidade").innerText = data.umidade + "%";
        document.getElementById("status").innerText = "";
    } catch (error) {
        console.log("Erro ao buscar dados:", error);
    }
}

async function buscarHistorico() {
    try {
        const response = await fetch(`${urlBase}/dados`);
        let texto = await response.text();

        texto = texto.replace(/'/g, '"');
        const dados = JSON.parse(texto);

        const historicoDiv = document.getElementById("historico");
        historicoDiv.innerHTML = "";

        dados.forEach(item => {
            historicoDiv.innerHTML += `<p>${item.temperatura}°C | ${item.umidade}%</p>`;
        });
    } catch (error) {
        console.log("Erro ao buscar histórico:", error);
    }
}

document.getElementById("btnHistorico").addEventListener("click", buscarHistorico);

buscarDados();
setInterval(buscarDados, 2000);