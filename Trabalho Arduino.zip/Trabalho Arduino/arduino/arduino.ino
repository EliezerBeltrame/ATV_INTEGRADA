#include <DHT.h>

#define DHTPIN 8
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float temp = dht.readTemperature();
  float umid = dht.readHumidity();

  if (!isnan(temp) && !isnan(umid)) {

    
    Serial.print("{\"temp\":");
    Serial.print(temp);
    Serial.print(",\"umid\":");
    Serial.print(umid);
    Serial.println("}");

  }

  delay(2000);
}