let reader;

const tempEl = document.getElementById("temp");
const umidadeEl = document.getElementById("umidade");
const statusEl = document.getElementById("status");

async function conectarArduino() {
  try {
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate: 9600 });

    const decoder = new TextDecoderStream();
    port.readable.pipeTo(decoder.writable);
    reader = decoder.readable.getReader();

    statusEl.innerText = "Arduino conectado";

    lerDados();

  } catch (error) {
    statusEl.innerText = "Erro ao conectar";
  }
}

async function lerDados() {
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    // Exemplo esperado: 25,60
    const dados = value.trim().split(",");

    if (dados.length === 2) {
      tempEl.innerText = dados[0] + "°C";
      umidadeEl.innerText = dados[1] + "%";
    }
  }
}