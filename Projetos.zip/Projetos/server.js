const express = require("express");
const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");

const app = express();
const port = 9000;

const serial = new SerialPort({ path: "COM6", baudRate: 9600 });

const parser = serial.pipe(new ReadlineParser({ delimiter: "\n" }));

let temperatura = 0;
let umidade = 0;

parser.on("data", (data) => {
  try {
    const json = JSON.parse(data);

    temperatura = json.temp;
    umidade = json.umid;

    console.log("Temp:", temperatura, "Umid:", umidade);
  } catch (erro) {
    console.log("Erro ao ler dados:", data);
  }
});

app.get("/temperatura", (req, res) => {
  res.json({
    temperatura,
    umidade
  });
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});